# Ledger — Student Budget & Savings Tracker

A Python console application that helps students track their allowance, record expenses, set aside savings, and check their remaining balance.

## Features

- Set a daily, weekly, or monthly allowance
- Add expenses with categories and optional notes
- Add savings and view transaction history
- Automatically calculate total spending, savings, and remaining balance
- View spending totals by category
- Delete transactions and reset the tracker
- Built-in arithmetic calculator
- Automatically save data locally in `budget_data.json`

## Requirements

- Python 3.8 or newer
- No third-party packages required

## How to run

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

```bash
python main.py
```

On some systems use `python3 main.py`.

## Menu

```text
1. View summary
2. Add expense
3. Add savings
4. View transactions
5. Delete a transaction
6. Calculator
7. Reset (start over)
0. Exit
```

## Example

For an allowance of ₱500, an expense of ₱150, and savings of ₱100, the remaining balance is ₱250.

## Project structure

- `main.py` — complete OOP console application
- `README.md` — project documentation
- `.gitignore` — keeps private/local files out of Git

## Classes

`Student`, `Expense`, `Saving`, `BudgetTracker`, and `Calculator`.

## Notes

The tracker stores one allowance amount and subtracts all recorded expenses and savings from it. It does **not** automatically replenish the allowance each day/week/month or filter entries by period. Use the reset feature when beginning a new budget period. `budget_data.json` is local-only and should not be committed to GitHub.
